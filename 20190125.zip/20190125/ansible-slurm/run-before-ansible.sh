#!/bin/bash

set -x -e

cd "$(dirname "${BASH_SOURCE[0]}")"

here=$(pwd)

tmp_dir=$(mktemp -d)
#trap "rm -rf $tmp_dir" EXIT

#git clone XX $tmp_dir/cim-sdk

cp -r ../cim-sdk $tmp_dir/
cp -r ../lib $tmp_dir/
cp -r ../lasolvd $tmp_dir/

##

(cd $tmp_dir/cim-sdk && python3 setup.py bdist_wheel -d $here/roles/cim-sdk/files)
(cd ../lib           && python3 setup.py sdist       -d $here/roles/shirokoro-python/files)
(cd ../lasolvd       && python3 setup.py sdist       -d $here/roles/lasolv-daemon/files)