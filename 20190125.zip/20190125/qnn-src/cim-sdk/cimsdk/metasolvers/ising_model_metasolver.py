#! /usr/bin/evn python3

import time
import json
import sys
from cimsdk.optimizers.sa_optimizer import SimulateAnnealingOptimizer
from cimsdk.utils.chart import plot_chart
import numpy as np

class IsingModelMetasolver:
    def __init__(self,jij,hi=None, optimizer=SimulateAnnealingOptimizer,
                 checking_quality=False,using_history=False,using_multipie_sdations=False,
                 optimizer_options=None):
        if not np.array_equal(jij, np.triu(jij)):
            raise ValueError("xxx")
        if not np.array_equal(np.diag(jij),np.zeros(jij.shape[0])):
            raise ValueError("xxx")
        if hi is None:
            hi=np.zeros(jij.shape[0])
        self.jij = jij
        self.hi = hi
        self.optimizer = optimizer
        self.checking_quality = checking_quality
        self.using_history = using_history
        self.using_multipie_sdations = using_multipie_sdations
        self.optimizer_optionss = None
        self.optimizer_options={} if optimizer_options is None else optimizer_options
    def solve(self):
        start_time = time.time()
        optimizer = self.optimizer(jij=self.jij,hi=self.hi,eval_func=IsingModelMetasolver.evalacate_energy,
                                   check_quality=self.checking_quality,
                                   **self.optimizer_options)
        solution,history = optimizer.minimize()
        elapsed_time = time.time() - start_time
        result = IsingModelResult(elapsed_time,solution,history)
        return  result
    @staticmethod
    def evalacate_energy(jij,hi,s):
        energy = - jij.dot(s).dot(s) - np.dot(hi,s)
        return energy
class IsingModelResult:
    def __init__(self,elapsed_time,solution,history=None):
        self.elapsed_time = elapsed_time
        self.solution = solution
        self.history = history
    def write(self,file_name = None,file_type='json',result_type='all',best_n=1):
        pass
    def get_all(self):
        pass
    def get_best(self):
        pass
    def get_best_n(self):
        pass
    def get_best_all(self):
        min_energy=min(self.solution,key = lambda s:s['energy'])['energy']
        result = {'elapsed_time':self.elapsed_time,'solutions':[s for s in self.solution if s['energy'] == min_energy]}
        if self.history is not None:
            result['history']=self.history
        return result

    def plot(self):
        plot_chart(self.history)


