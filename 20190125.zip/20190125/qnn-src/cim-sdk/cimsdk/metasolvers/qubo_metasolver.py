#! /usr/bin/evn python3

from cimsdk.optimizers.sa_optimizer import SimulateAnnealingOptimizer
from cimsdk.metasolvers.ising_model_metasolver import IsingModelMetasolver
import numpy as np
class QUBOmetasolver:
    def __init__(self, q_matrix, optimizer=SimulateAnnealingOptimizer,
                 checking_quality=False,  using_multipie_sdations=False,
                 optimizer_options={}):
        if not np.array_equal(q_matrix, np.triu(q_matrix)):
            raise ValueError("XXX")
        self.q_matrix = q_matrix
        self.optimizer = optimizer
        self.checking_quality=checking_quality
        self.using_multipie_sdations = using_multipie_sdations
        self.optimizer_options = optimizer_options

    def solve(self):
        qij = self.q_matrix-np.diag(np.diag(self.q_matrix))
        jij = - qij/4
        hi=np.zeros(self.q_matrix.shape[0])
        for i in range(self.q_matrix.shape[0]):
            hi[i] += -self.q_matrix[i,i]/2
            for j in range(i+1,self.q_matrix.shape[1]):
                hi[i] += -self.q_matrix[i,j]/4
                hi[j] += -self.q_matrix[i,j]/4
        solver = IsingModelMetasolver(jij*4,hi*4,
                                      optimizer=self.optimizer,
                                      checking_quality=self.checking_quality,
                                      using_multipie_sdations=self.using_multipie_sdations,
                                      optimizer_options=self.optimizer_options)
        result = QUBOmetasolver(solver.solve(),self.q_matrix)
        return result

class QUBOResult:
    def __init__(self, ising_model_result, q_matrix):
        self.ising_model_result = ising_model_result
        self.q_matrix = q_matrix

    def _add_qubo_key(self,result):
        for s in result['solutions']:
            s['qubo_spins'] = ((np.array(s['spins']) + 1) /2).astype(int).tolist()
            s['qubo_energy']=np.array(s['qubo_spins']).T.dot(self.q_matrix).dot(np.array(s['qubo_spins']))
        return result
    def get_all(self):
        return self._add_qubo_key(self.ising_model_result.get_all())

    def get_best(self):
        return self._add_qubo_key(self.ising_model_result.get_best())

    def get_best_n(self,n):
        return self._add_qubo_key(self.ising_model_result.get_best_n(n))

    def get_best_all(self):
        return self._add_qubo_key(self.ising_model_result.get_best_all())
