#! /usr/bin/evn python3

import numpy as np
import time
import warnings
from  cimsdk.utils.spin_packer  import SpinPacker

class SimulateAnnealingOptimizer:
    def __init__(self, jij,hi,eval_func,check_quality=False,silent=None, using_history= False,
                 max_stagation_count=5000,
                 start_temp=10,
                 end_temp=0.2,
                 cooling_rate=0.97,
                 start_repeat_time=1000,
                 repeat_num_rate=1.0):
        if silent is not None:
            warnings.warn("")
        self.jij =jij
        self.hi = hi
        self.eval_func = eval_func
        self.check_quality = check_quality
        self.silent = silent
        self.using_history = using_history
        self.start_temp = start_temp
        self.end_temp = end_temp
        self.cooling_rate = cooling_rate
        self.start_repeat_time = start_repeat_time
        self.repeat_num_rate = repeat_num_rate
