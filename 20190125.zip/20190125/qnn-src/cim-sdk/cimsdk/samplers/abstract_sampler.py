#! /usr/bin/evn python3

from abc import ABC,abstractmethod
import numpy as np

class AbstractSampler(ABC):
    @abstractmethod
    def sample(self,num):
        pass
    @abstractmethod
    def update_weights(self,new_jij,new_hi):
        pass
    @staticmethod
    def _check_jif_and_hi(jij,hi):
        if (len(jij.ndim !=2)) or (jij.shape[0] != jij.shape[1]):
            raise ValueError("XXXXXXXXXXXX")
        if not np.array_equal(jij, np.triu(jij)):
            raise ValueError("XXXXXXXXXXXX")
        if len(hi) != jij.shape[0]:
            raise ValueError("XXXXXXXXXXXX")