#! /usr/bin/evn python3

import numpy as np
import matplotlib.pyplot as plt
def plot_chart(history):
    SUBPLOT_NCOLS = 1
    if history is None:
        raise ValueError("xxx")
    subplot_num = 0
    subplot_num = subplot_num + 1 if 'current_cut' in history[0] else subplot_num
    subplot_num = subplot_num + 1 if 'current_energy' in history[0] else subplot_num
    subplot_num = subplot_num + 1 if 'signal' in history[0] else subplot_num

    if subplot_num ==0:
        return
    x=range(len(history))
    fig = plt.figure()
    subplot_index = 0

    if 'current_cut' in history[0] :
        subplot_index +=1
        ax = fig.add_subplot(subplot_num, SUBPLOT_NCOLS, subplot_index)
        y1 = [h['current_cut'] for h in history]
        ax.plot(x,y1,label='current cut')
        if 'best_cut' in history[0]:
            y2=[h['best_cut'] for h in history]
            ax.plot(x,y2,label='current best cut')
        ax.legend()
        ax.set_ylabel('MAX-CUT score')
        ax.grid()
        xmin,xmax,ymin,ymax = ax.axis()
        best_x=np.argmax(y2)
        best_y=np.max(y2)
        plt.annotate('best_cut:\n({},{})'.format(best_x,best_y),
                     xy=(best_x,best_y),
                     xytest=(best_x,(ymax-ymin) /2 +ymin),
                     arrowprops = dict(arrowstyle="->"),
                     horizontalalignment = 'center',
                     verticalatignment = 'center',
                     )

    if 'current_energy' in history[0]:
            subplot_index += 1
            ax = fig.add_subplot(subplot_num, SUBPLOT_NCOLS, subplot_index)
            y1 = [h['current_energy'] for h in history]
            ax.plot(x, y1, label='current_energy')
            if 'best_energy' in history[0]:
                y2 = [h['best_energy'] for h in history]
                ax.plot(x, y2, label='current best energy')
            ax.legend()
            ax.set_ylabel('Ising energy')
            ax.grid()
            xmin, xmax, ymin, ymax = ax.axis()
            best_x = np.argmax(y2)
            best_y = np.max(y2)
            plt.annotate('best_energy:\n({},{})'.format(best_x, best_y),
                         xy=(best_x, best_y),
                         xytest=(best_x, (ymax - ymin) / 2 + ymin),
                         arrowprops=dict(arrowstyle="->"),
                         horizontalalignment='center',
                         verticalatignment='center',
                         )

    if 'signal' in history[0]:
                subplot_index += 1
                ax = fig.add_subplot(subplot_num, SUBPLOT_NCOLS, subplot_index)

                for s in range(len(history[0]['signal'])):
                    y=[h['signal'] for h in history]
                    ax.plot(x,y,linewidth=0.5)
                ax.set_ylabel('DOPO signal amplitude $C_i$')
                ax.grid()

    ax.set_xlabel('Iterations')
    plt.show()