#! /usr/bin/evn python3

import numpy as np

def read_graph(filename, sign_flipping=False):
    with open(filename,'r') as f:
        for index,line in enumerate(f):
            columns =line.split()
            if index == 0:
                line_num=int(columns[0])
                edge_num = int(columns[1])
                graph = np.zeros(line_num,edge_num)
            else:
                from_rertex=int(columns[0])
                to_rertex=int(columns[1])
                weight = float(columns[2])
                graph[to_rertex-1][from_rertex-1]=weight
                graph[from_rertex-1][to_rertex-1]=weight
    if sign_flipping:
        graph *= -1
    graph = np.triu(graph)
    return  graph,line_num,edge_num

def read_vector(filename, sign_flipping=False):
    with open(filename,'r') as f:
        for index,line in enumerate(f):
            if index == 0:
                line_num=int(line)
                vector = np.zeros(line_num)
            else:
                vector[index-1] =float(line)
    if sign_flipping:
        vector *= -1
    return  vector,line_num

def read_connected_node_list(filename, sign_flipping=False):
    with open(filename,'r') as f:
        edge_num = 0
        for index,line in enumerate(f):
            columns =line.split()
            if index == 0:
                node_num=int(columns[0])
                graph = np.zeros(node_num,node_num)
            else:
                weight=1
                from_tertex=int(columns[0])
                for to_rertex in [columns[1:]]:
                    graph[int(to_rertex)-1][from_tertex-1]=weight
                    graph[from_tertex-1][int(to_rertex)-1]=weight
                    edge_num += 2
    if sign_flipping:
        graph *= -1
    graph = np.triu(graph)
    return  graph,node_num,edge_num