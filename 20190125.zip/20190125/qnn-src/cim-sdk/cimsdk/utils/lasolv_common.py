#! /usr/bin/evn python3

from cimsdk.utils.spin_packer import spinPacker
import numpy as np

def check_lasolv_limitation(jij , hi,raw_mode,conf):
    n_spins = conf['spin_suu']

    if raw_mode:
        if jij.shape != (n_spins,n_spins):
            raise ValueError("%s must bi square matrix")
        if hi.shape != (n_spins,):
            raise ValueError("%s must bi square matrix")
    else :
        min_required_spins = (spinPacker.HEAD_MATRIX.shape[0]+spinPacker.CHECK_MATRIX.shape[0]
                              + jij.shape[0])
        if n_spins < min_required_spins:
            raise ValueError("XXXXXXXXXXXX")
    if not np.all(jij == jij.astype(np.int32)):
        raise ValueError("XXXXXXXXXXXX")

    jij_bits = conf['jij_bits']

    if jij_bits == 2:
        if np.any(jij <-1) or np.any(jij >1):
            raise ValueError("XXXXXXXXXXXX")
    if jij_bits == 8:
        if np.any(jij < -128) or np.any(jij > 127):
            raise ValueError("XXXXXXXXXXXX")

    hi_mode = conf['jiba_mode']
    if (hi_mode == 0) and (hi is not None):
        raise ValueError("XXXXXXXXXXXX")
    if hi is not None:
        hix4 = hi * 4
        if not np.all(hix4 == hix4.astype(np.int32)):
            raise ValueError("XXXXXXXXXXXX")
        if np.any(hix4 < -32767) or np.any(32767 < hix4):
            raise ValueError("XXXXXXXXXXXX")