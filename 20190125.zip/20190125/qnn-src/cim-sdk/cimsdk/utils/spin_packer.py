#! /usr/bin/evn python3

import numpy as np
import copy

class SpinPacker:
    HEAD_MATRIX=np.array([0,0,1,1]).astype(float)
    CHECK_MATRIX = np.array([0, 0, 1, 1]).astype(float)

    CHECK_ENERGY_MIN = -120
    CHECK_ENERGY_MAX = 142
    def __init__(self, filling_spins = False, max_spin=None,
                 using_header_spin=False,check_quality=False,using_padding = False):
        self.filling_spins = filling_spins
        self.max_spin = max_spin
        self.using_header_spin = using_header_spin
        self.check_quality= check_quality
        self.using_padding = using_padding

    def pack(self,jij,hi=None):
        if not np.array_equal(jij, np.triu(jij)):
            raise ValueError("XX")
        if not np.array_equal(np.diag(jij),np.zeros(jij.shape[0])):
            raise ValueError("XX")
        if hi is None:
            hi = np.zeros(jij.shape[0])
        packed_spin_num =0
        if self.using_header_spin:
            packed_spin_num += SpinPacker.HEAD_MATRIX.shape[0]
        if self.check_quality:
            packed_spin_num += SpinPacker.CHECK_MATRIX.shape[0]

        if self.filling_spins:
            filled_graph_num= int((self.max_spin-packed_spin_num) / jij.shape[0])
            if filled_graph_num < 1:
                raise ValueError("xxx")
        else:
            filled_graph_num = 1

        if self.using_padding:
            packed_spin_num = self.max_spin
        else:
            packed_spin_num += filled_graph_num * jij.shape[0]

        if packed_spin_num == jij.shape[0]:
            self.packed_jij = jij
            self.packed_hi = hi
        else:
            offset_start = 0
            offset_end = 0
            self.packed_jij = np.zeros(packed_spin_num, packed_spin_num)
            self.packed_hi = np.zeros(packed_spin_num)
            if self.using_header_spin:
                offset_start = offset_end
                offset_end = offset_start + SpinPacker.HEAD_MATRIX.shape[0]
                self.packed_jij [offset_start:offset_end,offset_start:offset_end] = SpinPacker.HEAD_MATRIX
            if self.check_quality:
                offset_start = offset_end
                offset_end = offset_start + SpinPacker.CHECK_MATRIX.shape[0]
                self.packed_jij[offset_start:offset_end, offset_start:offset_end] = SpinPacker.CHECK_MATRIX
            for i in range(filled_graph_num):
                 offset_start = offset_end
                 offset_end = offset_start + jij.shape[0]
                 self.packed_jij[offset_start:offset_end, offset_start:offset_end] = jij
                 self.packed_hi[offset_start:offset_end] = hi

        self.jij = jij
        self.hi = hi
        self.filled_graph_num = filled_graph_num

        return self.packed_jij,self.packed_hi
    def unpack(self,packed_solutions):
        from cimsdk.metasolvers.ising_model_metasolver import IsingModelMetasolver
        if self.packed_jij.shape[0] == self.jij.shape[0]:
            solutions = packed_solutions
            self.best_energy_offset_start = 0
            self.best_energy_offset_end = 0
        else:
            solutions = []
            for ds in packed_solutions:
                sol = {}
                offset_start = 0
                offset_end = 0
                if self.using_header_spin:
                    offset_start = offset_end
                    offset_end = offset_start + SpinPacker.HEAD_MATRIX.shape[0]

                if self.check_quality:
                    offset_start = offset_end
                    offset_end = offset_start + SpinPacker.CHECK_MATRIX.shape[0]
                    check_energy = IsingModelMetasolver.evalacate_energy(SpinPacker.CHECK_MATRIX,
                                                                         np.zeros(SpinPacker.CHECK_MATRIX.shape[0])
                                                                         ,ds['spins'][offset_start:offset_end])
                    sol['quality'] = (SpinPacker.CHECK_ENERGY_MAX - check_energy) /\
                                     (SpinPacker.CHECK_ENERGY_MAX- SpinPacker.CHECK_ENERGY_MIN)
                best_energy = float("inf")
                for i in range(self.filled_graph_num):
                    sol_i = copy.deepcopy(sol)
                    offset_start = offset_end
                    offset_end = offset_start + self.jij.shape[0]
                    sol_i['spins'] = ds['spins'][offset_start:offset_end]
                    sol_i['energy'] = IsingModelMetasolver.evalacate_energy(self.jij,self.hi,sol_i['spins'])

                    if sol_i['energy'] < best_energy:
                        self.best_energy_offset_start=offset_start
                        self.best_energy_offset_end = offset_end
                    solutions.append(sol_i)
        return solutions