#! /usr/bin/evn python3

import numpy as np

def check_square_matrix(X,name):
    if not (X.ndim == 2 and (X.shape[0] == X.shape[1])):
        raise ValueError("%s must bi square matrix"% name)

def check_distance_matrix(D,name):
    if not (np.all(D>0) and D.ndim == 2 and (D.shape[0] == D.shape[1] and np.array_equal(D,D.T))):
        raise ValueError("%s must bi square matrix"% name)