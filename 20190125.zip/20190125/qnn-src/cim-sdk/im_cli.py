#! /usr/bin/evn python3

import cimsdk.utils.file_io as file_io
import cimsdk.metasolvers.ising_model_metasolver
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-j','--jij',required=True,help='jij file name')
    args = parser.parse_args()
    if args.optimizer == 'br':
        from cimsdk.optimizers.bf_optimizer import BruteForOptimizer
        optimizer = BruteForOptimizer
    if args.optimizer == 'sa':
        from cimsdk.optimizers.sa_optimizer import SimulateAnnealingOptimizer
        optimizer = SimulateAnnealingOptimizer
    