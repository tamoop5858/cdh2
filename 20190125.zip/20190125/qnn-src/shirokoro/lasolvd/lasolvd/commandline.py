#! /usr/bin/evn python3

import errno
import lasolvd.lasolvd.fcntl as fcntl
import json
import os
import os.path
import subprocess
import sys
import tempfile
import lasolvd.lasolvd.daemon as daemon

def main():
    with tempfile.TemporaryDirectory() as tmpdir:
        pathin = os.path.join(tmpdir,"stdin")
        pathout = os.path.join(tmpdir, "stdout")
        patherr = os.path.join(tmpdir, "stderr")

        os.makefifo(pathin)
        os.makefifo(pathout)
        os.makefifo(patherr)
    req = {
        'stdin':pathin,
        'stdout':pathout,
        'stderr':patherr,
        'argv':sys.argv
        }
    write_request(req)

    with open(pathin, 'w') as infifo:
        proin = subprocess.Popen(['cat'] , stdin=sys.stdin, stdout=infifo)
        proout = subprocess.Popen(['cat' , pathout], stdout=sys.stdout)
        proerr = subprocess.Popen(['cat', patherr], stdout=sys.stderr)
    proin.wait()
    proout.wait()
    proerr.wait()
def write_request(req):
    try:
        fd = os.open(daemon.REQUEST_FIFO , os.O_NONBLOCK | os.O_WRONLY)
    except OSError as e:
        if e.errno == errno.ENXIO:
            print("The request FIFO is not opened : try restarting LASOLV Daemon" , file=sys.stderr)
            sys.exit(1)
        raise

    try:
        fcntl.fcntl(fd, fcntl.F_SELFT , os.O_WRONLY)
        os.write(fd, json.dumps(req).encode())
    finally:
        os.close()
if __name__ == "__main__":
    main()