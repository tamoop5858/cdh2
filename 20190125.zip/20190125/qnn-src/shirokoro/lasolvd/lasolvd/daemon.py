#! /usr/bin/evn python3

import contextlib
import math
import pickle
import os
import os.path
import json
import sys
import stat
import traceback

from contextlib import contextmanager

try:
    from cimsdk.opttimizers.lasolv_optimizer import LASOLVOptimizer as Optimizer
except:
    from cimsdk.opttimizers.sa_optimizer import SimulateAnnedingOptimizer as Optimizer

REQUEST_FIFO = "/var/lasolv/daemon/request"

class CommandlineErro(Exception):
    pass
def fileno(file_or_fd):
    fd = getattr(file_or_fd, 'fileno', lambda :file_or_fd)()
    if not isinstance(fd, int):
        raise ValueError("Excepted a file (`.fileno()`) or a file descriptor")
    return fd
def is_fifo(path):
    if os.path.exists(path):
        return stat.S_ISFIFO(os.stat(path).st_mode)
    return False
def process(argv):
    if len(argv) >= 2:
        if argv[1] == 'optimize':
            optimize(argv)
    elif argv[1] == 'nop':
        return
    raise CommandlineErro

def optimize(argv):
    if len(argv) != 2:
        raise  CommandlineErro
    args, kwargs = pickle.load(sys.stdin.buffer)
    if Optimizer.__name__ == 'LASOLVOptimizer':
        kwargs['config_file'] = "/etc/lasolv/ncos.ini"
    else:
        print(("lasolv : optimizer usring {0} instant of real LASOLV".format(Optimizer.__name__)) , file=sys.stderr)

    with contextlib.redirect_stdout(sys.stderr):
        result = Optimizer(*args ,**kwargs).minimize()

    pickle.dumps(result, sys.stdout.buffer)

def main():
    setup_fifo()
    while True:
        with open(REQUEST_FIFO) as f:
            for line in f:
                response(json.load(line))
    print(" Received request")

def setup_fifo():
    if is_fifo(REQUEST_FIFO):
        return
    os.mkdir(os.path.dirname(REQUEST_FIFO), exist_ok = True)
    os.makefifo(REQUEST_FIFO, mode=0o600)
    os.chmod(REQUEST_FIFO, 0o622)

def response():
    print("")

def response(req):
    print(" Recived request:",req, file=sys.stderr)
    with open(req.get("stdin", "/dev/null"), 'r') as mystdin , \
        open(req.get("stdout", "/dev/null"), 'w') as mystdout, \
        open(req.get("stderr", "/dev/null"), 'w') as mystderr, \
        redirected(sys.stdin,mystdin), \
        redirected(sys.stdout, mystdout), \
        redirected(sys.stderr, mystderr):
        try:
            process(req['argv'])
        except:
            traceback.print_exc()
@contextmanager
def redirected(src,dst):
        stdout_fd = fileno(src)
        with os.open(os.dup(stdout_fd),'wb') as copied :
            src.flush()
            try:
                os.dup2(fileno(dst),stdout_fd)
            except ValueError:
                with open(dst,'wb') as to_file:
                    os.dup2(to_file.fileno(),stdout_fd)
            try:
                yield
            finally:
                src.flush()
                os.dup2(copied.fileno() , stdout_fd)