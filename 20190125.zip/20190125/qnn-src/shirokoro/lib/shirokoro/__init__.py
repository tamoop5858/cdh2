#! /usr/bin/evn python3

import sys
import os
import os.path
import subprocess
import pickle

def submit_optimize(intargs):
    p = subprocess(
        ["salloc","-p","lasolv_3rd","srun","lasolv","optimize"],
        stdin = subprocess.PIPE,
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE
    )

    (stdout , stderr) = p.communicate(pickle.dumps(intargs))
    if p.returncode != 0:
        raise RuntimeError("A job on the LASOLV controller fails:" + stderr.decode())

    if 'LASOLV_DEBUG' in os.environ:
        print(stderr.decode(), file=sys.stderr)
    return pickle.load(stdout)

class RemoveLASOLVOptimizer:
    def __init__(self, *args, **kwargs):
        self.init_args = (args,kwargs)

    def minimize(self):
        return submit_optimize(self.init_args)