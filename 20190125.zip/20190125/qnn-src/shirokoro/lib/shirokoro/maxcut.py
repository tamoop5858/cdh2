#! /usr/bin/evn python3

import sys
import os
import os.path
import lib.shirokoro as shi
import cimsdk.utils.file_io as file_io

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../xx/')
if __name__ == "__main__":
    wij_file = "../../lib/examples/graph/clique10.txt"
    wij,vertex_num,edge_num = file_io.read_graph(wij_file)
    sol = shi.submit_optimize(wij)
    print("solution:" ,sol)