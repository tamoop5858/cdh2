package com.bas.common.util;
 
import org.apache.commons.lang3.StringUtils;
import software.amazon.awssdk.auth.credentials.*;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.paginators.ListObjectsV2Iterable;
import software.amazon.awssdk.services.sts.model.Credentials;
 
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.*;
 
 
public class S3Util {
 
    private S3Util(){}
 
    public static S3Client builder(String regionStr) {
        Region region = Region.US_EAST_1;//default region
        if(StringUtils.isNotEmpty(regionStr)) {
            region = Region.of(regionStr);
        }
        return S3Client.builder().region(region).build();
    }
    public static S3Client builder(Credentials credentials) {
        Region region = Region.US_EAST_1;//default region
        
        AwsSessionCredentials awsCreds = AwsSessionCredentials.create(
                credentials.accessKeyId(),
                credentials.secretAccessKey(),
                credentials.sessionToken());
        return S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(awsCreds)).region(region).build();
    }
}