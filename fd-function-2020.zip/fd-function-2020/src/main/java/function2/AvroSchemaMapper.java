package function2;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;

import avro.CanData;
import avro.CanIdc001;
import avro.CanIdc022;
import avro.CanIdc122;
import avro.CanIdc201;
import avro.canInfo;
import avro.canInfoAll;

public class AvroSchemaMapper implements Serializable{

	public Schema getSchema() {
		Schema schema;
		try {
			schema = new Schema.Parser().parse(new File("data/canInfo.avsc"));
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return schema;
	}


	public Schema getSchema1() {
		Schema schema;
		schema = canInfo.getClassSchema();
		return schema;
	}

	public Schema getSchemaCanInfoAll() {
		Schema schema;
		schema = canInfoAll.getClassSchema();
		return schema;
	}

	public GenericRecord map(List<CanUnitBean> canUnitBeanList) {
		GenericRecord record = new GenericData.Record(getSchema());
		record.put("canId", String.valueOf(canUnitBeanList.get(0).getCanId()));
		record.put("canTime", canUnitBeanList.get(0).getCanTime());
		//record.put("convertedData", canUnitBeanList.get(0).getConvertedDataMap());
        return record;
	}


	public GenericRecord mapAll(List<CanUnitBean> canUnitBeanList) {
		GenericRecord record = new GenericData.Record(getSchemaCanInfoAll());
		record.put("canId", String.valueOf(canUnitBeanList.get(0).getCanId()));
		record.put("canTime", canUnitBeanList.get(0).getCanTime());
		GenericRecord canDataRecord =  new GenericData.Record(CanData.getClassSchema());
		GenericRecord c001Record =  new GenericData.Record(CanIdc001.getClassSchema());
		GenericRecord c022Record =  new GenericData.Record(CanIdc022.getClassSchema());
		GenericRecord c122Record =  new GenericData.Record(CanIdc122.getClassSchema());
		GenericRecord c201Record =  new GenericData.Record(CanIdc201.getClassSchema());

//		c001Record.put("c001_dummy15",canUnitBeanList.get(0).getConvertedDataMap().get("c001_dummy15"));
//		c001Record.put("c001_dummy16",canUnitBeanList.get(0).getConvertedDataMap().get("c001_dummy16"));
//		c001Record.put("c001_dummy17",canUnitBeanList.get(0).getConvertedDataMap().get("c001_dummy17"));
//		canDataRecord.put("c001", c001Record);
//
//		c022Record.put("c022_dummy15",canUnitBeanList.get(0).getConvertedDataMap().get("c022_dummy15"));
//		c022Record.put("c022_dummy16",canUnitBeanList.get(0).getConvertedDataMap().get("c022_dummy16"));
//		c022Record.put("c022_dummy17",canUnitBeanList.get(0).getConvertedDataMap().get("c022_dummy17"));
//		c022Record.put("c022_dummy18",canUnitBeanList.get(0).getConvertedDataMap().get("c022_dummy18"));
//		canDataRecord.put("c022", c022Record);
//
//		c122Record.put("c122_dummy15",canUnitBeanList.get(0).getConvertedDataMap().get("c122_dummy15"));
//		c122Record.put("c122_dummy16",canUnitBeanList.get(0).getConvertedDataMap().get("c122_dummy16"));
//		c122Record.put("c122_dummy17",canUnitBeanList.get(0).getConvertedDataMap().get("c122_dummy17"));
//		c122Record.put("c122_dummy18",canUnitBeanList.get(0).getConvertedDataMap().get("c122_dummy18"));
//		c122Record.put("c122_dummy19",canUnitBeanList.get(0).getConvertedDataMap().get("c122_dummy19"));
//		canDataRecord.put("c122", c122Record);
//
//		c201Record.put("c201_dummy15",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy15"));
//		c201Record.put("c201_dummy16",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy16"));
//		c201Record.put("c201_dummy17",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy17"));
//		c201Record.put("c201_dummy18",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy18"));
//		c201Record.put("c201_dummy19",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy19"));
//		c201Record.put("c201_dummy20",canUnitBeanList.get(0).getConvertedDataMap().get("c201_dummy20"));
//		canDataRecord.put("c201", c201Record);


		c001Record.put("c001_dummy15",2L);
		c001Record.put("c001_dummy16",2L);
		c001Record.put("c001_dummy17",1L);
		canDataRecord.put("c001", c001Record);

		c022Record.put("c022_dummy15",2L);
		c022Record.put("c022_dummy16",1L);
		c022Record.put("c022_dummy17",1L);
		c022Record.put("c022_dummy18",1L);
		canDataRecord.put("c022", c022Record);

		c122Record.put("c122_dummy15",1L);
		c122Record.put("c122_dummy16",1L);
		c122Record.put("c122_dummy17",1L);
		c122Record.put("c122_dummy18",1L);
		c122Record.put("c122_dummy19",1L);
		canDataRecord.put("c122", c122Record);

		c201Record.put("c201_dummy15",1L);
		c201Record.put("c201_dummy16",1L);
		c201Record.put("c201_dummy17",1L);
		c201Record.put("c201_dummy18",1L);
		c201Record.put("c201_dummy19",1L);
		c201Record.put("c201_dummy20",1L);
		canDataRecord.put("c201", c201Record);

		record.put("canData", Collections.singletonList(canDataRecord));

        return record;
	}
}
