package function2;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class XiaoFu {

	//データ構造体作成
	public Map<Long, Map<Long, Map<Short, CanUnitBean>>> dataStructure(
			List<CanUnitBean> sortedCanUnitBeeanList) {

		Map<Long, Map<Long, Map<Short, CanUnitBean>>> aa = new TreeMap<Long, Map<Long, Map<Short, CanUnitBean>>>();
		Map<Long, Map<Short, CanUnitBean>> bb = new TreeMap<Long, Map<Short, CanUnitBean>>();
		Map<Short, CanUnitBean> cc = null;

		//Map<Long ,Map<Short,List<CanUnitBean>>> のデータ構造を作成する.
		for (CanUnitBean bean : sortedCanUnitBeeanList) {
			short canId = bean.getCanId();
			long canTime = bean.getCanTime();
			long tmStamp = (long) (canTime - canTime % 100);
			long tripCounter = bean.getTripCounter();///仮にgetTripCounter

			if (!aa.keySet().contains(tripCounter)) {
				//aa = new HashMap<Long ,Map<Long,Map<Short,CanUnitBean>>>();
				if (!bb.keySet().contains(tmStamp)) {
					bb = new TreeMap<Long, Map<Short, CanUnitBean>>();
					cc = new TreeMap<Short, CanUnitBean>();

					cc.put(canId, bean);
					bb.put(tmStamp, cc);
				} else {

					cc.put(canId, bean);
					bb.put(tmStamp, cc);
				}
				aa.put(tripCounter, bb);

			} else {
				if (!bb.keySet().contains(tmStamp)) {
					//	     bb = new HashMap<Long,Map<Short,CanUnitBean>>();
					cc = new TreeMap<Short,CanUnitBean>();

					cc.put(canId, bean);
					bb.put(tmStamp, cc);
				} else {

					cc.put(canId, bean);
					bb.put(tmStamp, cc);
				}
				aa.put(tripCounter, bb);
			}

		}

		System.out.println(aa);
		System.out.println("-------------------------------------------------------------------------");
		for (Map.Entry<Long, Map<Long, Map<Short, CanUnitBean>>> c1 : aa.entrySet()) {
			System.out.println("Trip Counter : " + c1.getKey());
			//System.out.println(c1.getValue());
			//nullComplemented.put(c1.getKey(), c1.getValue());
			for (Map.Entry<Long, Map<Short, CanUnitBean>> c2 : c1.getValue().entrySet()) {
				System.out.println("timestamp is : " + c2.getKey());
				System.out.println(c2.getValue());
			}
		}

		return aa;
	}

	//NULL 補完
	public Map<Long, Map<Long, Map<Short, CanUnitBean>>> nullComplement(
			Map<Long, Map<Long, Map<Short, CanUnitBean>>> data) {
		Map<Long, Map<Long, Map<Short, CanUnitBean>>> nullComplemented = new TreeMap<Long, Map<Long, Map<Short, CanUnitBean>>>();
		Map<Long, Map<Short, CanUnitBean>> timestampMapCurent = new TreeMap<Long, Map<Short, CanUnitBean>>();


		Map<Short, CanUnitBean> canidMapCurent = null;
		Map<Short, CanUnitBean> canidMapTmp = null;

		for (Map.Entry<Long, Map<Long, Map<Short, CanUnitBean>>> c1 : data.entrySet()) {//tripcounter単位ループ
			timestampMapCurent = new TreeMap<Long, Map<Short, CanUnitBean>>();
			for (Map.Entry<Long, Map<Short, CanUnitBean>> c2 : c1.getValue().entrySet()) {//timestamp単位ループ
				//System.out.println(c2.getKey());
				//System.out.println(c2.getValue());
				if ( canidMapTmp == null) {
					canidMapTmp = c2.getValue();//canid CanUnitBeanのMap
				}

				canidMapCurent = c2.getValue();

				for (Short canId : canidMapTmp.keySet()) {
					if (!canidMapCurent.containsKey(canId)) {
						canidMapCurent.put(canId, canidMapTmp.get(canId));
					}
				}
				canidMapTmp = canidMapCurent;
				timestampMapCurent.put(c2.getKey(), canidMapCurent);


				nullComplemented.put(c1.getKey(), timestampMapCurent);//最終に格納

				System.out.println(nullComplemented);
			}

		}
		System.out.println("---------------------");
		System.out.println(nullComplemented);
		System.out.println("---------------------");
		return null;

	}

	//直前値付与
	public Map<Long, Map<Long, Map<Short, CanUnitBean>>> oldValueAdd(
			Map<Long, Map<Long, Map<Short, CanUnitBean>>> data,Map<Short, List<String>> tagetIdLabel) {
		Map<Long, Map<Long, Map<Short, CanUnitBean>>> oldValueAdd = new TreeMap<Long, Map<Long, Map<Short, CanUnitBean>>>();
		Map<Long, Map<Short, CanUnitBean>> timestampMapCurent = new TreeMap<Long, Map<Short, CanUnitBean>>();


		Map<Short, CanUnitBean> canidMapCurent = null;
		Map<Short, CanUnitBean> canidMapTmp = null;

		for (Map.Entry<Long, Map<Long, Map<Short, CanUnitBean>>> c1 : data.entrySet()) {//tripcounter単位ループ
			timestampMapCurent = new TreeMap<Long, Map<Short, CanUnitBean>>();
			for (Map.Entry<Long, Map<Short, CanUnitBean>> c2 : c1.getValue().entrySet()) {//timestamp単位ループ
				//System.out.println(c2.getKey());
				//System.out.println(c2.getValue());
				if ( canidMapTmp == null) {
					canidMapTmp = c2.getValue();//canid CanUnitBeanのMap
				}

				canidMapCurent = c2.getValue();

				for (Short canId : tagetIdLabel.keySet()) {
					if (canidMapTmp.containsKey(canId) && canidMapCurent.containsKey(canId)) {

						for (String labelName : tagetIdLabel.get(canId)) {
							Object o = canidMapTmp.get(canId).getConvertedDataMap().get(labelName);
							CanUnitBean bean = canidMapCurent.get(canId);
							Map<String ,?> convertedDataMap = bean.getConvertedDataMap();
							//convertedDataMap.put("prex_" + labelName, o);

							bean.setConvertedDataMap(convertedDataMap);
							canidMapCurent.put(canId, bean);

						}

					}
				}
				canidMapTmp = canidMapCurent;
				timestampMapCurent.put(c2.getKey(), canidMapCurent);


				oldValueAdd.put(c1.getKey(), timestampMapCurent);//最終に格納

				System.out.println(oldValueAdd);
			}

		}
		System.out.println("---------------------");
		System.out.println(oldValueAdd);
		System.out.println("---------------------");
		return null;

	}
}
