package function2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class XiaoFuTest {

	public static void main(String[] args) {

		CanUnitBean	canUnitBean11 = Unit.createCanUnitBean((short)0x01,"1506787111010");
		CanUnitBean	canUnitBean12 = Unit.createCanUnitBean((short)0x22,"1506787111020");
		CanUnitBean	canUnitBean13 = Unit.createCanUnitBean((short)0x122,"1506787111030");
		CanUnitBean	canUnitBean14 = Unit.createCanUnitBean((short)0x201,"1506787111050");

		//CanUnitBean	canUnitBean11_1 = Unit.createCanUnitBean2((short)0x01,"1506787111110");
		CanUnitBean	canUnitBean12_1 = Unit.createCanUnitBean2((short)0x22,"1506787111120");
		CanUnitBean	canUnitBean13_1 = Unit.createCanUnitBean2((short)0x122,"1506787111130");
		CanUnitBean	canUnitBean14_1 = Unit.createCanUnitBean2((short)0x201,"1506787111150");

		canUnitBean11.setTripCounter(1000L);
		canUnitBean12.setTripCounter(1000L);
		canUnitBean13.setTripCounter(1000L);
		canUnitBean14.setTripCounter(1000L);

		//canUnitBean11_1.setTripCounter(1000L);
		canUnitBean12_1.setTripCounter(1000L);
		canUnitBean13_1.setTripCounter(1000L);
		canUnitBean14_1.setTripCounter(1000L);


		CanUnitBean	canUnitBean21 = Unit.createCanUnitBean((short)0x01,"1506787115010");
		CanUnitBean	canUnitBean22 = Unit.createCanUnitBean((short)0x22,"1506787115020");
		CanUnitBean	canUnitBean23 = Unit.createCanUnitBean((short)0x122,"1506787115030");
		//CanUnitBean	canUnitBean24 = Unit.createCanUnitBean((short)0x201,"1506787115050");

		CanUnitBean	canUnitBean21_1 = Unit.createCanUnitBean2((short)0x01,"1506787115110");
		CanUnitBean	canUnitBean22_1 = Unit.createCanUnitBean2((short)0x22,"1506787115120");
		CanUnitBean	canUnitBean23_1 = Unit.createCanUnitBean2((short)0x122,"1506787115130");
		CanUnitBean	canUnitBean24_1 = Unit.createCanUnitBean2((short)0x201,"1506787115150");

		canUnitBean21.setTripCounter(2000L);
		canUnitBean22.setTripCounter(2000L);
		canUnitBean23.setTripCounter(2000L);
		//canUnitBean24.setTripCounter(2000L);

		canUnitBean21_1.setTripCounter(2000L);
		canUnitBean22_1.setTripCounter(2000L);
		canUnitBean23_1.setTripCounter(2000L);
		canUnitBean24_1.setTripCounter(2000L);

		List<CanUnitBean> canList = new ArrayList<CanUnitBean>();
		canList.add(canUnitBean11);
		canList.add(canUnitBean12);
		canList.add(canUnitBean13);
		canList.add(canUnitBean14);

		//canList.add(canUnitBean11_1);
		canList.add(canUnitBean12_1);
		canList.add(canUnitBean13_1);
		canList.add(canUnitBean14_1);

		canList.add(canUnitBean21);
		canList.add(canUnitBean22);
		canList.add(canUnitBean23);
		//canList.add(canUnitBean24);

		canList.add(canUnitBean21_1);
		canList.add(canUnitBean22_1);
		canList.add(canUnitBean23_1);
		canList.add(canUnitBean24_1);

		XiaoFu xiaoFu= new XiaoFu();

		Map<Long, Map<Long, Map<Short, CanUnitBean>>>  data = xiaoFu.dataStructure(canList);
System.out.println("");
System.out.println("");
System.out.println("");
		Map<Long, Map<Long, Map<Short, CanUnitBean>>>  nullAdd = xiaoFu.nullComplement(data);
    }
}
