package fd.rawstore.util;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class CtreateDirectory {
	private static final String TIME_TO_PATH = "yyyy/MM/dd/HHmm";
	public static String createDirectoryPathFromTime(ZonedDateTime z) {
		DateTimeFormatter f = DateTimeFormatter.ofPattern(TIME_TO_PATH);

		String[] dateElementes = z.format(f).split("/");
		return "year=" + dateElementes[0] + "/month=" + dateElementes[1] +
				"/day=" + dateElementes[2] + "/hh_mm" + dateElementes[3];

	}
}
