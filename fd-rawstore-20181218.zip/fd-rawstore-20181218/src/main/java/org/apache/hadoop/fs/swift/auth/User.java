/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.fs.swift.auth;


/**
 * Describes credentials to log in Swift using Keystone authentication.
 * THIS FILE IS MAPPED BY JACKSON TO AND FROM JSON.
 * DO NOT RENAME OR MODIFY FIELDS AND THEIR ACCESSORS.
 */
public class User {
  /**
   * user login
   */
  private Domain domain;
  private String id;
  private String name;


  /**
   * user password
   */
  private String password;

  /**
   * default constructor
   */
  public User() {
  }

  /**
   * @param username user login
   * @param password user password
   */
  public User(Domain domain, String id, String name, String password) {
	  this.domain = domain;
	  this.id = id;
	  this.name = name;
      this.password = password;
  }

  /**
   * @return user password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password user password
   */
  public void setPassword(String password) {
    this.password = password;
  }

public Domain getDomain() {
	return domain;
}

public void setDomain(Domain domain) {
	this.domain = domain;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}


}

