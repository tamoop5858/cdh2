package fd.rawstore;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.function.ParquetWriteFunction;
import fd.rawstore.function.UnpackMessageFunction;

public class CreateJavaStreamingContext implements Function0<JavaStreamingContext>{
	private static final long serialVersionUID = - 2022345678L;
	@Override
	public JavaStreamingContext call() throws Exception {
		final long batchInterval = 60000L;
		SparkConf conf = new SparkConf().setAppName("StreamingDriver").setMaster("local[2]");
		JavaStreamingContext ssc = new JavaStreamingContext(conf, Durations.milliseconds(batchInterval));
		ssc.checkpoint("/tmp/checkpoint");

		CreateKafkaStream creater = new CreateKafkaStream();
		creater.setJssc(ssc);

		JavaPairDStream<String, CanDataAnnotatedBean> blos =
				//creater.createStream().map(new SetTimeFunction<Tuple2<String,byte[]>>())
				creater.createStream()
				.mapToPair(new UnpackMessageFunction())
				.repartition(10);
		blos.print();
		ParquetWriteFunction rawStoreWriteFunction = new ParquetWriteFunction();
		//SequenceWriteFunction rawStoreWriteFunction = new SequenceWriteFunction();
		rawStoreWriteFunction.setRawStoreRootDir("data/rawstor/");
		blos.foreachRDD(rawStoreWriteFunction);

		return ssc;
	}

}
