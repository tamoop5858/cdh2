package fd.rawstore;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import scala.Tuple2;



public class CreateKafkaStream {

	protected JavaStreamingContext jssc;

	public void setJssc(JavaStreamingContext jssc) {
		this.jssc = jssc;
	}

	public JavaPairDStream<String, byte[]> createStream(){
		Map<String, Object> kafkaParams = new HashMap();

		kafkaParams.put("bootstrap.servers", "localhost:9092");//"172.23.8.144:9092,172.23.8.179:9092,172.23.8.59:9092"

		kafkaParams.put("group.id", "rawstorApp");
		kafkaParams.put("key.deserializer", StringDeserializer.class);
		kafkaParams.put("value.deserializer", ByteArrayDeserializer.class);

		Set<String> topicSet = new HashSet<String>(Arrays.asList("anntopic"));
		final JavaInputDStream<ConsumerRecord<String, byte[]>> stream =
				KafkaUtils.createDirectStream(this.jssc , LocationStrategies.PreferConsistent(),
					ConsumerStrategies.<String,byte[]>Subscribe(topicSet, kafkaParams));

		return stream.mapToPair(record -> new Tuple2<>(record.key(), record.value()));

	}
}
