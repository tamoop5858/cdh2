package fd.rawstore;

import fd.rawstore.kafka.producer.Producer2;

public class ProducerDriver  {
	public static void main(String[] args) {
		Producer2 producer = new Producer2("anntopic",true);//同期・非同期
		producer.start();
	}
}