package fd.rawstore.driver.parquet;

import java.util.Arrays;

import org.apache.hadoop.mapreduce.Job;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrameWriter;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

import fd.rawstore.bin.CanDataAnnotatedBean;

public class ParquetWriterDriverS3a {

	public static void main(String[] args) {
		SparkConf conf=new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");
		JavaSparkContext sc = new JavaSparkContext(conf);

		Job job = getJob();

		org.apache.hadoop.conf.Configuration confHaddop = job.getConfiguration();

		byte[] message = new byte[] {0x00,0x01};
		CanDataAnnotatedBean bean1= new CanDataAnnotatedBean();
		bean1.setVin("111");
		bean1.setRecicvetime(12345L);
		bean1.setMessage(message);
		CanDataAnnotatedBean bean2= new CanDataAnnotatedBean();
		bean2.setVin("222");
		bean2.setRecicvetime(12345L);
		bean2.setMessage(message);
		JavaRDD<CanDataAnnotatedBean> rdd = sc.parallelize(Arrays.asList(bean1,bean2),1);


        confHaddop.set("fs.s3a.endpoint", "192.168.88.85:8080");
        confHaddop.set("fs.s3a.path.style.access", "true");
        confHaddop.set("fs.s3a.connection.ssl.enabled", "false");
        confHaddop.set("fs.s3a.access.key", "test:tester");
        confHaddop.set("fs.s3a.secret.key", "testing");
        confHaddop.set("fs.s3a.signing-algorithm", "S3SignerType");

//①
        SparkSession sparkSession =SparkSession.builder().getOrCreate();
		Dataset<Row> ds = sparkSession.createDataFrame(rdd, CanDataAnnotatedBean.class);


//		rdd.mapToPair(new TranstormToSequenceFileFormat("fffff".getBytes(StandardCharsets.UTF_8)))
//		.saveAsNewAPIHadoopFile("s3a://buckettest/testParquet/" + String.valueOf(System.currentTimeMillis()), NullWritable.class, BytesWritable.class,
//				ParquetOutputFormat.class,confHaddop);

//②

//		ds.write()
//		  .mode(SaveMode.Append)
//		  .format("parquet")
//		  .save("s3a://buckettest/testParquet/" + String.valueOf(System.currentTimeMillis()));

		DataFrameWriter<Row> writer = ds.write();
		writer.mode(SaveMode.Append).parquet("s3a://buckettest/testParquet/" + String.valueOf(System.currentTimeMillis()));

//		writer.mode(SaveMode.Append).parquet("data/parquet/" + String.valueOf(System.currentTimeMillis()));
//		System.out.println( "---------------------------------------");

	}

    private static Job getJob() {
    	Job job;
    	try {
    		job = Job.getInstance();
    	} catch(Exception e) {
    		e.printStackTrace();
    		throw new RuntimeException(e);
    	}
    	return job;
    }
}
