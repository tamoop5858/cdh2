package fd.rawstore.driver.seq;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;

import scala.Tuple2;

public class SeqReaderDriverS3a {

	public static void main(String[] args) {
		SparkConf conf=new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");
		JavaSparkContext sc = new JavaSparkContext(conf);

		Job job = getJob();

		org.apache.hadoop.conf.Configuration confHaddop = job.getConfiguration();
		confHaddop.set("mapreduce.outpu.basename", String.valueOf(System.currentTimeMillis()));
		confHaddop.set("mapreduce.output.fileoutputformat.compress", "true");
		confHaddop.set("mapred.map.output.compress.codec", "org.apache.hadoop.io.compress.SnappyCodec");
		confHaddop.set("mapred.map.output.compress.type", "BLOCK");


        confHaddop.set("fs.s3a.endpoint", "192.168.88.85:8080");
        confHaddop.set("fs.s3a.path.style.access", "true");
        confHaddop.set("fs.s3a.connection.ssl.enabled", "false");
        confHaddop.set("fs.s3a.access.key", "test:tester");
        confHaddop.set("fs.s3a.secret.key", "testing");
        confHaddop.set("fs.s3a.signing-algorithm", "S3SignerType");

        JavaPairRDD<NullWritable, BytesWritable> pairRDD =
        		sc.newAPIHadoopFile("s3a://buckettest/testSeq/*/", SequenceFileInputFormat.class, NullWritable.class, BytesWritable.class, confHaddop);

        pairRDD.foreach(new VoidFunction<Tuple2<NullWritable, BytesWritable>>() {
            @Override
            public void call(Tuple2<NullWritable, BytesWritable> tp2) throws Exception {
                System.out.println(tp2._2.toString());

            }
        });


		System.out.println( "---------------------------------------");

	}

    private static Job getJob() {
    	Job job;
    	try {
    		job = Job.getInstance();
    	} catch(Exception e) {
    		e.printStackTrace();
    		throw new RuntimeException(e);
    	}
    	return job;
    }
}
