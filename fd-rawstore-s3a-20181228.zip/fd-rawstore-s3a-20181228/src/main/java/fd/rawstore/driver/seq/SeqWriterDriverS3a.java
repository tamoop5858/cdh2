package fd.rawstore.driver.seq;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.function.TranstormToSequenceFileFormat;

public class SeqWriterDriverS3a {

	public static void main(String[] args) {
		SparkConf conf=new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");
		JavaSparkContext sc = new JavaSparkContext(conf);

		Job job = getJob();

		org.apache.hadoop.conf.Configuration confHaddop = job.getConfiguration();

		byte[] message = new byte[] {0x00,0x01};
		CanDataAnnotatedBean bean1= new CanDataAnnotatedBean();
		bean1.setVin("111");
		bean1.setRecicvetime(12345L);
		bean1.setMessage(message);
		CanDataAnnotatedBean bean2= new CanDataAnnotatedBean();
		bean2.setVin("222");
		bean2.setRecicvetime(12345L);
		bean2.setMessage(message);
		JavaRDD<CanDataAnnotatedBean> rdd = sc.parallelize(Arrays.asList(bean1,bean2),1);

		confHaddop.set("mapreduce.outpu.basename", String.valueOf(System.currentTimeMillis()));
		confHaddop.set("mapreduce.output.fileoutputformat.compress", "true");
		confHaddop.set("mapred.map.output.compress.codec", "org.apache.hadoop.io.compress.SnappyCodec");
		confHaddop.set("mapred.map.output.compress.type", "BLOCK");


        confHaddop.set("fs.s3a.endpoint", "192.168.88.85:8080");
        confHaddop.set("fs.s3a.path.style.access", "true");
        confHaddop.set("fs.s3a.connection.ssl.enabled", "false");
        confHaddop.set("fs.s3a.access.key", "test:tester");
        confHaddop.set("fs.s3a.secret.key", "testing");
        confHaddop.set("fs.s3a.signing-algorithm", "S3SignerType");


		rdd.mapToPair(new TranstormToSequenceFileFormat("fffff".getBytes(StandardCharsets.UTF_8)))
		.saveAsNewAPIHadoopFile("s3a://buckettest/testSeq/" + String.valueOf(System.currentTimeMillis()), NullWritable.class, BytesWritable.class,
				SequenceFileOutputFormat.class,confHaddop);

		System.out.println( "---------------------------------------");

	}

    private static Job getJob() {
    	Job job;
    	try {
    		job = Job.getInstance();
    	} catch(Exception e) {
    		e.printStackTrace();
    		throw new RuntimeException(e);
    	}
    	return job;
    }
}
