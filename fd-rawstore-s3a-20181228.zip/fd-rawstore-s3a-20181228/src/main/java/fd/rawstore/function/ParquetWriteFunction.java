package fd.rawstore.function;

import java.time.ZonedDateTime;

import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.DataFrameWriter;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.util.CtreateDirectory;

public class ParquetWriteFunction
 implements VoidFunction<JavaPairRDD<String, CanDataAnnotatedBean>>{
	private static final long serialVersionUID = - 2022345678L;
	protected String rawStoreRootDir;
	public void setRawStoreRootDir(String rawStoreRootDir) {
		this.rawStoreRootDir = rawStoreRootDir;
	}
	@Override
	public void call(JavaPairRDD<String, CanDataAnnotatedBean> rdd) {
		write(rdd.values());
	}

	protected  void write(JavaRDD<CanDataAnnotatedBean> rdd) {
		if(!rdd.isEmpty()) {
			ZonedDateTime now = ZonedDateTime.now();
			final String path =
					new Path(this.rawStoreRootDir,CtreateDirectory.createDirectoryPathFromTime(now))
					.toString();
			SparkSession sparkSession =SparkSession.builder().getOrCreate();
			Dataset<Row> ds = sparkSession.createDataFrame(rdd, CanDataAnnotatedBean.class);
			DataFrameWriter<Row> writer = ds.write();
			writer.mode(SaveMode.Append).parquet(path);
		} else {
			System.out.println("rdd.isEmpty");
		}
	}
}
