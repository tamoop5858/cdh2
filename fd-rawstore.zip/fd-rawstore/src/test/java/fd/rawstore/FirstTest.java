package fd.rawstore;

public class FirstTest {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("------");
	}

}
