package fd.fd_kafka_client_sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

public class ConsumerDriver  {
	public static void main(String[] args) {
        Properties properties = new Properties();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, "my-consumer");

        //指定しない場合のデフォルト値は「latest」となり、Consumerが起動した跡にTopicに登録されたデータを読み出していくことになります。
        //「earliest」と指定しているのですが、こちらは「--from-beginning」
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        KafkaConsumer<Integer, String> consumer =
                new KafkaConsumer<>(properties, new IntegerDeserializer(), new StringDeserializer());

        List<ConsumerRecord<Integer, String>> received = new ArrayList<>();

        consumer.subscribe(Arrays.asList("my-topic"));

        while (received.size() < 10000) {
            ConsumerRecords<Integer, String> records = consumer.poll(1000L);

            records.forEach(received::add);

            for (ConsumerRecord<Integer, String> record : records) {
                System.out.println("Received message: (" + record.key() + ", " + record.value() + ") at offset " + record.offset());
            }
        }

	}
}