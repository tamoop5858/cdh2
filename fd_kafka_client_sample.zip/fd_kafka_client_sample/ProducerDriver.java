package fd.fd_kafka_client_sample;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.stream.IntStream;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

public class ProducerDriver  {
	public static void main(String[] args) {
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

        //Apache Kafkaに登録するレコードとして、KeyとValueのSerializerがそれぞれ必要になります
        try (KafkaProducer<Integer, String> producer =
                     new KafkaProducer<>(properties, new IntegerSerializer(), new StringSerializer())) {

            IntStream
                    .rangeClosed(1, 10)
                    .forEach(i -> {
                        try {
                        	//ProducerRecordのコンストラクタには、Topic名、Key、Valueをそれぞれ設定します
                            producer.send(new ProducerRecord<>("my-topic", i, "value" + i)).get();
                        } catch (InterruptedException | ExecutionException e) {
                            throw new RuntimeException(e);
                        }
                    });
        }
	}
}