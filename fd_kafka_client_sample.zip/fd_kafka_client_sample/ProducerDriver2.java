package fd.fd_kafka_client_sample;


public class ProducerDriver2  {
	public static void main(String[] args) {
		Producer producer = new Producer("my-topic",false);//同期・非同期
		producer.start();
	}
}