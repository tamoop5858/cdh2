package org.debugroom.mynavi.sample.aws.lambda;

import org.springframework.cloud.function.adapter.aws.SpringBootApiGatewayRequestHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApiGatewayEventHandler extends SpringBootApiGatewayRequestHandler {
//org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler
}
