package org.debugroom.mynavi.sample.aws.lambda.functions;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApiGatewayEventFunction implements Function<Message<String>, Message<String>> {

    @Override
    public Message<String> apply(Message<String> inputMessage) {
        //log.info("Message : " + inputMessage.getPayload().getTest());
    	System.out.println("11111");
        return new Message<String>() {
            @Override
            public String getPayload() {
            	System.out.println("22222");
                return "Complete!";
            }

            @Override
            public MessageHeaders getHeaders() {
            	System.out.println("333333");
                Map<String, Object> headers = new HashMap<>();
                return new MessageHeaders(headers);
            }
        };

    }

}
