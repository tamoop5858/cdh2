package com.amazonaws.samples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class testRDS {

	public static void main(String[] args) {
//		AWSCredentials credentials = new BasicAWSCredentials(
//				"AKIAQ3CGY5MR3V7LSWFQ",
//				"++HC2JZloemH/HgJAUIGc+pgFE3tt2gTw5aTxDJS");
		Connection conn = getRemoteConnection();

		System.out.println(conn.toString());
		Statement setupStatement = null;
		Statement readStatement = null;
		ResultSet resultSet = null;
		String results = "";
		try {
		setupStatement = conn.createStatement();
	    String createTable = "CREATE TABLE Beanstalk (Resource char(50));";
	    String insertRow1 = "INSERT INTO Beanstalk (Resource) VALUES ('EC2 Instance');";
	    String insertRow2 = "INSERT INTO Beanstalk (Resource) VALUES ('RDS Instance');";

	    setupStatement.addBatch(createTable);
	    setupStatement.addBatch(insertRow1);
	    setupStatement.addBatch(insertRow2);
	    //setupStatement.executeBatch();///////////////////////////初期だけ

	    readStatement = conn.createStatement();
	    resultSet = readStatement.executeQuery("SELECT Resource FROM Beanstalk;");

	    //resultSet.first();
	    results = resultSet.getString("Resource");
	    resultSet.next();
	    results += ", " + resultSet.getString("Resource");

	    System.out.println(results);
	    resultSet.close();
	    readStatement.close();
	    setupStatement.close();

	    conn.close();
		} catch (SQLException ex) {
		    // Handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    ex.printStackTrace();
		  } finally {
		    System.out.println("Closing the connection.");
		    if (conn != null) try { conn.close(); } catch (SQLException ignore) {}
		  }

	}

	private static Connection getRemoteConnection() {
			try {
				Class.forName("org.postgresql.Driver");
				String dbName = "postgres";
				String userName = "postgres";
				String password = "12345678";
				String hostname = "database-3.cjlvl0gcoihe.ap-northeast-1.rds.amazonaws.com";
				String port = "5432";
				String jdbcUrl = "jdbc:postgresql://" + hostname + ":" + port + "/" + dbName + "?user=" + userName
						+ "&password=" + password;

				Connection con = DriverManager.getConnection(jdbcUrl);
				return con;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
	}
}
