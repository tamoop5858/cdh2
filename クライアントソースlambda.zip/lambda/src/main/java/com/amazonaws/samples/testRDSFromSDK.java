package com.amazonaws.samples;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.rds.model.CreateDBInstanceRequest;
import com.amazonaws.services.rdsdata.AWSRDSData;
import com.amazonaws.services.rdsdata.AWSRDSDataClientBuilder;
import com.amazonaws.services.rdsdata.model.ExecuteSqlRequest;
import com.amazonaws.services.rdsdata.model.ExecuteSqlResult;

public class testRDSFromSDK {

	public static void main(String[] args) {


		//AWSRDSData client = AWSRDSDataClientBuilder.standard().withRegion(Regions.AP_NORTHEAST_1).build();
		AWSRDSData client  = AWSRDSDataClientBuilder.standard()
        .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("database-3.cjlvl0gcoihe.ap-northeast-1.rds.amazonaws.com", "ap-northeast-1"))
        .build();

//		ExecuteSqlRequest executeSqlRequest = new ExecuteSqlRequest()
//				.withDatabase("postgres")
//				.withSqlStatements("select count(*) from test;");

		ExecuteSqlRequest executeSqlRequest = createExecuteSqlRequest("select count(*) from test;");

		ExecuteSqlResult executeSqlRequest22 = client.executeSql(executeSqlRequest);

		CreateDBInstanceRequest createDBInstanceRequest = new CreateDBInstanceRequest()
				//.withAllocatedStorage(dbAllocatedStorage)
				//.withDBInstanceClass(dbClass)
				//.withDBInstanceIdentifier(dbInstanceIdentifier)
				.withDBName("postgres")
				.withMasterUsername("postgres")
				.withMasterUserPassword("12345678");
				//.withMultiAZ(Boolean.valueOf(multiAZ))
				//.withCopyTagsToSnapshot(Boolean.TRUE)
				//.withEngine("MySQL")
				//.withEngineVersion("5.6");
//		ExecuteStatementRequest executeStatementRequest = new ExecuteStatementRequest()
//				.withDatabase("postgres")
//				.withSql("select count(*) from test") ;
//
//		ExecuteStatementResult result = client.executeStatement(executeStatementRequest);
//		List<List<Field>> re = result.getRecords();
	}
    private static ExecuteSqlRequest createExecuteSqlRequest(String sql) {
        ExecuteSqlRequest request = new ExecuteSqlRequest();
        //request.setAwsSecretStoreArn(SECRET_STORE_ARN);
        request.setDbClusterOrInstanceArn("postgres");
        request.setDatabase("postgres");
        request.setSqlStatements(sql);
        return request;
    }
}
