package com.example.lambda;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;
import com.amazonaws.services.securitytoken.model.Credentials;

public class AcessChenyong {

    public static void main(String[] args) {

        try {
            //クレデンシャルプロバイダの生成
            AWSCredentialsProvider cp = new InstanceProfileCredentialsProvider(true);

            //セキュリティトークンサービスの生成(一時クレデンシャルを生成するためのサービス)
            EndpointConfiguration endpointConfiguration = new AwsClientBuilder.EndpointConfiguration("",
            		"ap-northeast-1");
            AWSSecurityTokenService sts = AWSSecurityTokenServiceClientBuilder
            					.standard()
            					.withCredentials(cp)
            					.withRegion(Regions.AP_NORTHEAST_1)
            					//.withEndpointConfiguration(endpointConfiguration)
            					.build();

            //アカウントBのアカウントIDなどのロールARNを設定し、一時クレデンシャルを取得
            String ROLE_B_ARN = "arn:aws:iam::916756198055:role/FB-TEST";
            String ROLE_SESSION_NAME = "FB-TEST";
            AssumeRoleRequest roleRequest = new AssumeRoleRequest()
            					.withRoleArn(ROLE_B_ARN)
            					.withRoleSessionName(ROLE_SESSION_NAME);
            AssumeRoleResult result = sts.assumeRole(roleRequest);
            Credentials credentials = result.getCredentials();

            //write out the response
            System.out.println("done");

        } catch(Exception e) {
            e.printStackTrace();
        }
        // snippet-end:[lambda.java2.invoke.main]
    }
}

