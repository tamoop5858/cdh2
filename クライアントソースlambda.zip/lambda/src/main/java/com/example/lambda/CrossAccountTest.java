package com.example.lambda;

import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClient;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;

public class CrossAccountTest {

  static final String ROLE_ARN = "arn:aws:iam::916756198055:role/FB-TEST";
  static final String ROLE_SESSION_NAME = "hoge";
  public static void main(String[] args) {
	    AWSSecurityTokenService sts = new AWSSecurityTokenServiceClient();
	    AssumeRoleResult result = sts.assumeRole(new AssumeRoleRequest()
	        .withRoleArn(ROLE_ARN)
	        .withRoleSessionName(ROLE_SESSION_NAME));

//	    Credentials credentials = result.getCredentials();
//	    AWSCredentials sessionCredentials
//	        = new BasicSessionCredentials(credentials.getAccessKeyId(),
//	        credentials.getSecretAccessKey(),
//	        credentials.getSessionToken());
//	    AmazonS3 s3 = new AmazonS3Client(sessionCredentials);
//	    for (Bucket bucket : s3.listBuckets()) {
//	      System.out.println(bucket);
//	    }
  }
}