package com.example.lambda;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.glue.AWSGlue;
import com.amazonaws.services.glue.AWSGlueClientBuilder;
import com.amazonaws.services.glue.model.Column;
import com.amazonaws.services.glue.model.CreateTableRequest;
import com.amazonaws.services.glue.model.StorageDescriptor;
import com.amazonaws.services.glue.model.TableInput;
import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClient;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;
import com.amazonaws.services.securitytoken.model.Credentials;

public class GlueTest {

    public static void main(String[] args) {

        try {

            StorageDescriptor storageDescriptor = new StorageDescriptor();
            		//.withBucketColumns(bucketColumns);
            Map<String,String> parameters= new HashMap<String,String>();
            parameters.put("classification", "Parquet");

            ArrayList<Column> cols = new ArrayList<Column>();
            Column col = new Column();
            col.setName("id");
            col.setType("string");
            cols.add(col);

            storageDescriptor.withLocation("s3://suwabe/").withColumns(cols);
            TableInput tableInput = new TableInput()
            		.withName("jiang_glue_table01")
            		.withTableType("parquet")
            		.withStorageDescriptor(storageDescriptor)
            		.withParameters(parameters);

            //クレデンシャルプロバイダの生成
            AWSCredentialsProvider cp = new InstanceProfileCredentialsProvider(true);

            //セキュリティトークンサービスの生成(一時クレデンシャルを生成するためのサービス)
            EndpointConfiguration endpointConfiguration = new AwsClientBuilder.EndpointConfiguration("",
            		"ap-northeast-1");
//            AWSSecurityTokenService sts = AWSSecurityTokenServiceClientBuilder
//            					.standard()
//            					.withCredentials(cp)
//            					.withRegion(Regions.AP_NORTHEAST_1)
//            					//.withEndpointConfiguration(endpointConfiguration)
//            					.build();

            AWSSecurityTokenService sts = new AWSSecurityTokenServiceClient();

            //アカウントBのアカウントIDなどのロールARNを設定し、一時クレデンシャルを取得
            String ROLE_B_ARN = "arn:aws:iam::916756198055:role/FB-TEST";
            String ROLE_SESSION_NAME = "FB-TEST";
            AssumeRoleRequest roleRequest = new AssumeRoleRequest()
            					.withRoleArn(ROLE_B_ARN)
            					.withRoleSessionName(ROLE_SESSION_NAME);
            AssumeRoleResult result = sts.assumeRole(roleRequest);
            Credentials credentials = result.getCredentials();

            //一時クレデンシャルのアクセスキーIDやシークレットアクセスキーでクレデンシャルを生成
            BasicSessionCredentials sessionCredentials =
            					new BasicSessionCredentials(
            					credentials.getAccessKeyId(),
            					credentials.getSecretAccessKey(),
            					credentials.getSessionToken());

            // Glueクライアントの生成
            AWSGlue awsGlueClient1 =
            	    AWSGlueClientBuilder.standard().withCredentials(
        					new AWSStaticCredentialsProvider(sessionCredentials))
            					.withRegion(Regions.AP_NORTHEAST_1)
            					.build();

			//AWSGlueClient
             //createTableRequest
            CreateTableRequest createTableRequest = new CreateTableRequest()
            		.withCatalogId("916756198055")//アカウントB
                   .withDatabaseName("testdb")
                   .withTableInput(tableInput)
                   ;

            awsGlueClient1.createTable(createTableRequest);

            //write out the response
            System.out.println("done");

        } catch(Exception e) {
            e.printStackTrace();
        }
        // snippet-end:[lambda.java2.invoke.main]
    }
}

