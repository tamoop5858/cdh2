package com.example.lambda;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.glue.AWSGlue;
import com.amazonaws.services.glue.AWSGlueClientBuilder;
import com.amazonaws.services.glue.model.Column;
import com.amazonaws.services.glue.model.CreateTableRequest;
import com.amazonaws.services.glue.model.StorageDescriptor;
import com.amazonaws.services.glue.model.TableInput;

public class GlueTest_jiang {

    public static void main(String[] args) {

        try {
            AWSGlue awsGlueClient =
            	    AWSGlueClientBuilder.standard().withRegion(Regions.AP_NORTHEAST_1).build();
//データストアの追加 インクルードパス:   s3://suwabe/
//データ形式の選択 Parquet
//スキーマの定義 id string

            StorageDescriptor storageDescriptor = new StorageDescriptor();
            		//.withBucketColumns(bucketColumns);
            Map<String,String> parameters= new HashMap<String,String>();
            parameters.put("classification", "Parquet");

            ArrayList<Column> cols = new ArrayList<Column>();
            Column col = new Column();
            col.setName("id");
            col.setType("string");
            cols.add(col);

            storageDescriptor.withLocation("s3://suwabe/").withColumns(cols);
            TableInput tableInput = new TableInput()
            		.withName("jiang_glue_table01")
            		.withTableType("parquet")
            		.withStorageDescriptor(storageDescriptor)
            		.withParameters(parameters);


			//AWSGlueClient
             //createTableRequest
            CreateTableRequest createTableRequest = new CreateTableRequest()
            		.withCatalogId("058130492195")//諏訪部のアカウント
                   .withDatabaseName("testdb")
                   .withTableInput(tableInput)
                   ;

            awsGlueClient.createTable(createTableRequest);

            //write out the response
            System.out.println("done");

        } catch(Exception e) {
            e.printStackTrace();
        }
        // snippet-end:[lambda.java2.invoke.main]
    }
}

