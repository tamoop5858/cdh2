package org.debugroom.mynavi.sample.aws.lambda;

import org.debugroom.mynavi.sample.aws.lambda.rds.Employee;
import org.debugroom.mynavi.sample.aws.lambda.rds.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.amazonaws.services.lambda.runtime.Context;

//@SuppressWarnings("unchecked")
public class ApiGatewayEventHandler extends SpringBootRequestHandler<Object, String> {
	//org.debugroom.mynavi.sample.aws.lambda.ApiGatewayEventHandler

	@Override
	public String handleRequest(Object input, Context context) {
		super.handleRequest(input, context);
		context.getLogger().log("Input: " + input);
		System.out.println("22222");


		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
    	Session session = sessionFactory.openSession();
    	System.out.println("000000000  session " + session.toString());
        session.beginTransaction();

        System.out.println("000000000  session 1111111111111111  beginTransaction ");

        Employee employee = new Employee();
        employee.setId(66);
        employee.setName("from handler");
        session.save(employee);
        System.out.println("000000000  session 1111111111111111 session.save(employee) ");
        session.getTransaction().commit();

        System.out.println("000000000  session 1111111111111111 session.getTransaction().commit();");
System.out.println("---------------　やすなり　----------------------");


		// TODO: implement your handler
		return "Hello from Lambda1!";
	}

	@Override
	protected String convertEvent(Object event) {
		System.out.println("3333333 convertEvent 333333");
		return event.toString();
	}
}
