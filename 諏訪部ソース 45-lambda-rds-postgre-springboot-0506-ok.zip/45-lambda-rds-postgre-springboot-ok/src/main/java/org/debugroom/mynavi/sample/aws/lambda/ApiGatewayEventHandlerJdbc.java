package org.debugroom.mynavi.sample.aws.lambda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.amazonaws.services.lambda.runtime.Context;

//@SuppressWarnings("unchecked")
public class ApiGatewayEventHandlerJdbc extends SpringBootRequestHandler<Object, String> {
	//org.debugroom.mynavi.sample.aws.lambda.ApiGatewayEventHandlerJdbc

	@Override
	public String handleRequest(Object input, Context context) {
		super.handleRequest(input, context);
		context.getLogger().log("Input: " + input);
		System.out.println("22222");


		Connection conn = getRemoteConnection();

		System.out.println(conn.toString());
		Statement setupStatement = null;
		Statement readStatement = null;
		ResultSet resultSet = null;
		String results = "";
		try {
		setupStatement = conn.createStatement();
	    String createTable = "CREATE TABLE Beanstalk (Resource char(50));";
	    String insertRow1 = "INSERT INTO Beanstalk (Resource) VALUES ('EC2 Instance');";
	    String insertRow2 = "INSERT INTO Beanstalk (Resource) VALUES ('RDS Instance');";

	    setupStatement.addBatch(createTable);
	    setupStatement.addBatch(insertRow1);
	    setupStatement.addBatch(insertRow2);
	    setupStatement.executeBatch();///////////////////////////初期だけ

	    readStatement = conn.createStatement();
	    resultSet = readStatement.executeQuery("SELECT id FROM employee;");

	    //resultSet.first();
	    results = resultSet.getString("id");
	    resultSet.next();
	    results += ", " + resultSet.getString("id");

	    System.out.println(results);
	    resultSet.close();
	    readStatement.close();
	    setupStatement.close();

	    conn.close();
		} catch (SQLException ex) {
		    // Handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    ex.printStackTrace();
		  } finally {
		    System.out.println("Closing the connection.");
		    if (conn != null) try { conn.close(); } catch (SQLException ignore) {}
		  }

//		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
//    	Session session = sessionFactory.openSession();
//    	System.out.println("000000000  session " + session.toString());
//        session.beginTransaction();
//
//        System.out.println("000000000  session 1111111111111111  beginTransaction ");
//
//        Employee employee = new Employee();
//        employee.setId(66);
//        employee.setName("from handler");
//        session.save(employee);
//        System.out.println("000000000  session 1111111111111111 session.save(employee) ");
//        session.getTransaction().commit();

        System.out.println("000000000  session 1111111111111111 session.getTransaction().commit();");
System.out.println("---------------　やすなり　----------------------");


		// TODO: implement your handler
		return "Hello from Lambda1!";
	}

	@Override
	protected String convertEvent(Object event) {
		System.out.println("3333333 convertEvent 333333");
		return event.toString();
	}

	private static Connection getRemoteConnection() {
		try {
			Class.forName("org.postgresql.Driver");
			String dbName = "postgres";
			String userName = "postgres";
			String password = "12345678";
			String hostname = "database-2.c5tsus5pub3a.ap-northeast-1.rds.amazonaws.com";
			String port = "5432";
			String jdbcUrl = "jdbc:postgresql://" + hostname + ":" + port + "/" + dbName + "?user=" + userName
					+ "&password=" + password;

			Connection con = DriverManager.getConnection(jdbcUrl);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
}
}
