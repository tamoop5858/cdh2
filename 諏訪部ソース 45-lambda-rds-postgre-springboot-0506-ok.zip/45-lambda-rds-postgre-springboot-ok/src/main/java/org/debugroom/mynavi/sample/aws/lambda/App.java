package org.debugroom.mynavi.sample.aws.lambda;

import org.debugroom.mynavi.sample.aws.lambda.rds.Employee;
import org.debugroom.mynavi.sample.aws.lambda.rds.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App {

    public static void main(String[] args) {
    	System.out.println("000000000");
        SpringApplication.run(App.class, args);

        //doPostgre();
    }

    public static void doPostgre() {
    	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		System.out.println("000000000  sessionFactory " + sessionFactory.toString());
        try {
        	Session session = sessionFactory.openSession();
        	System.out.println("000000000  main session " + session.toString());
            session.beginTransaction();

            System.out.println("000000000  main session 1111111111111111  beginTransaction ");

            Employee employee = new Employee();
            employee.setId(55);
            employee.setName("from main ");
            session.save(employee);
            System.out.println("000000000 main  session 1111111111111111 session.save(employee) ");
            session.getTransaction().commit();

            System.out.println("000000000  main session 1111111111111111 session.getTransaction().commit();");
            session.close();

            System.out.println("000000000  main session 1111111111111111 session.close()"+ session.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.exit(1);
    }
}

