package org.debugroom.mynavi.sample.aws.lambda.rds;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

/**
 * @author arungupta
 */
public class EmployeeHandler implements RequestHandler<Request, String> {
//org.debugroom.mynavi.sample.aws.lambda.rds.EmployeeHandler
    @Override
    public String handleRequest(Request request, Context context) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            Employee employee = new Employee();
            employee.setId(request.id);
            employee.setName(request.name);
            session.save(employee);
            session.getTransaction().commit();
        }
System.out.println("-------------------------------------" +String.format("Added %s %s.", request.id, request.name) );
        return String.format("Added %s %s.", request.id, request.name);
    }
}
