
package org.debugroom.mynavi.sample.aws.lambda.rds;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (null != sessionFactory)
            return sessionFactory;
        try {
        Configuration configuration = new Configuration();


        String jdbcUrl = "jdbc:postgresql://database-2.c5tsus5pub3a.ap-northeast-1.rds.amazonaws.com:5432/postgres";
        configuration.setProperty("hibernate.connection.url", jdbcUrl);
        configuration.setProperty("hibernate.connection.username", "postgres");
        configuration.setProperty("hibernate.connection.password", "12345678");

        configuration.setProperty("hibernate.connection.driver_class", "org.postgresql.Driver");
        configuration.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
        configuration.setProperty("hibernate.jdbc.lob.non_contextual_creation", "true");

        configuration.setProperty("show_sql", "true");
        configuration.setProperty("connection.pool_size", "1");


        configuration.addAnnotatedClass(org.debugroom.mynavi.sample.aws.lambda.rds.Employee.class);

        Configuration cxf = configuration.configure();
System.out.println("3333333333333  HibernateUtil 33333333333333  configuration.configure(); " + cxf.toString());

        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(cxf.getProperties()).build();

System.out.println("444444444444  HibernateUtil 44444444444  serviceRegistry " + serviceRegistry.toString());

            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
System.out.println("5555555555  HibernateUtil 555555555  sessionFactory " + sessionFactory.toString());
        } catch (Exception e) {
        	e.printStackTrace();
            System.err.println("Initial SessionFactory creation failed. 666666666666666666" + e);
            throw new ExceptionInInitializerError(e);
        }
        return sessionFactory;
    }
}
