package com.example.demo;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.example.demo.model.Weather;
import com.example.demo.service.WeatherService;
//@SuppressWarnings("unchecked")
//@Configuration
//@EnableAutoConfiguration
//@ComponentScan("com.example.demo")
public class ApiGatewayEventHandler implements RequestHandler<Object, String> {
	//com.example.demo.ApiGatewayEventHandler

	@Override
	public String handleRequest(Object input, Context context) {
		//super.handleRequest(input, context);
		context.getLogger().log("Input: " + input);
System.out.println("2222222222222222222222222222222222222222222222222222222222");

		WeatherService weatherService = Application.getBean(WeatherService.class);
System.out.println("3333333 333333 weatherService "  + weatherService.toString());
		List<Weather> weatherDataList = weatherService.findAllWeatherData();
		weatherDataList.stream().forEach(weather -> System.out.println(weather.getName()));
		// TODO: implement your handler
		return "Hello from Lambda1!";
	}

}
