package com.example.demo;

import java.util.List;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.amazonaws.services.lambda.runtime.Context;
import com.example.demo.model.Weather;
import com.example.demo.service.WeatherService;

public class ApiGatewayEventHandler2 extends SpringBootRequestHandler<Object, String> {
	//com.example.demo.ApiGatewayEventHandler2

	@Override
	public String handleRequest(Object input, Context context) {
		//super.handleRequest(input, context);
		context.getLogger().log("Input: " + input);
System.out.println("2222222222222222222222222222222222222222222222222222222222");

		WeatherService weatherService = Application.getBean(WeatherService.class);
System.out.println("3333333 333333 weatherService "  + weatherService.toString());
		List<Weather> weatherDataList = weatherService.findAllWeatherData();
		weatherDataList.stream().forEach(weather -> System.out.println(weather.getName()));
		// TODO: implement your handler
		return "Hello from Lambda1!";
	}
	
	@Override
	protected String convertEvent(Object event) {
		System.out.println("3333333 convertEvent 333333");
		return event.toString();
	}
}
