package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
//@Configuration
//@EnableAutoConfiguration
//@ComponentScan("com.example.demo")
public class Application {
    private static ConfigurableApplicationContext context = null;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    public static <T> T getBean(Class<T> clazz){
        return getContext().getBean(clazz);
    }

    private static ConfigurableApplicationContext getContext(){
        if(context == null){
            String args[] = new String[1];
            args[0] = "dummy";
            context = SpringApplication.run(Application.class, args);
        }
System.out.println("3333333 333333 ConfigurableApplicationContext "  + context.toString());
        return context;
    }
}