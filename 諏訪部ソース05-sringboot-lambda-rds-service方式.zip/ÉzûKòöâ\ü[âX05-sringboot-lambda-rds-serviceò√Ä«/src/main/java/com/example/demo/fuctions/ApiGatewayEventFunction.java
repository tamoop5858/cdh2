package com.example.demo.fuctions;

import java.util.function.Function;


public class ApiGatewayEventFunction implements Function<Object, String> {

    @Override
    public String apply(Object inputMessage) {
    	System.out.println("11111111 ApiGatewayEventFunction apply --------");
     return "aaaaa";

    }

}
