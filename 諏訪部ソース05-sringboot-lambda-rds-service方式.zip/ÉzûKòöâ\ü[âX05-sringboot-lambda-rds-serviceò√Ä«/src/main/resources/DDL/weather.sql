create table weather (
    id              serial   primary key,   -- ID
    location_id     int,                    -- 地名ID
    name            varchar(20),            -- 地名
    temperature     int,                    -- 気温
    humidity        int,                    -- 湿度
    date_time       timestamp               -- 日時
);

insert into weather (location_id, name, temperature, humidity, date_time) values
   (1, '東京', 15, 55, '2019-04-10 09:00:00'),
   (1, '東京', 16, 53, '2019-04-10 10:00:00'),
   (1, '東京', 17, 40, '2019-04-10 11:00:00'),
   (2, '那覇', 20, 65, '2019-04-10 09:00:00'),
   (2, '那覇', 22, 67, '2019-04-10 10:00:00'),
   (2, '那覇', 25, 69, '2019-04-10 11:00:00');