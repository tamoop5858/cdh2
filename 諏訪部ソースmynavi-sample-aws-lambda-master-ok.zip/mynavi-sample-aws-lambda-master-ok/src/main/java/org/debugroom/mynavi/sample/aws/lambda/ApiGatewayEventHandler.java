package org.debugroom.mynavi.sample.aws.lambda;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.amazonaws.services.lambda.runtime.Context;

@SuppressWarnings("unchecked")
public class ApiGatewayEventHandler extends SpringBootRequestHandler<Object, String> {
	//org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler

	@Override
	public String handleRequest(Object input, Context context) {
		super.handleRequest(input, context);
		context.getLogger().log("Input: " + input);
		System.out.println("22222");

		// TODO: implement your handler
		return "Hello from Lambda1!";
	}

	@Override
	protected String convertEvent(Object event) {
		System.out.println("3333333 convertEvent 333333");
		return event.toString();
	}
}
