package com.example.demo;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.model.Weather;
import com.example.demo.service.WeatherService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication
public class AppDemo {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(AppDemo.class, args);

        WeatherService weatherService = context.getBean(WeatherService.class);
        List<Weather> weatherDataList = weatherService.findAllWeatherData();



        weatherDataList.stream().forEach(weather -> System.out.println(weather.getName()));


    }



}
