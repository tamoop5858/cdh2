package com.amazonaws.lambda.futuredata;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

//import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
//import software.amazon.awssdk.services.emr.EmrClient;
//import software.amazon.awssdk.services.emr.model.*;

import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduce;
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduceClientBuilder;
import com.amazonaws.services.elasticmapreduce.model.*;
import com.amazonaws.services.elasticmapreduce.util.StepFactory;


public class LambdaEmrHandler implements RequestHandler<Map<String, Object>, String> {

    @Override
    public String handleRequest(Map<String, Object> input, Context context) {
    	LambdaLogger logger = context.getLogger();
    	
       AWSCredentials credentials = getCredentials();
       
    	Request req = new Request(input);
    	logger.log("method:"  + req.getMethod() + "path:"  + req.getPath());
    	switch( req.getMethod()) {
    	case "GET":      return listEMR(credentials, context);
    	case "PUT":  
    	case "POST":    //createEMR(credentials, context);
    	case "DELETE": //deleteEMR(credentials);
    	default:  return listEMR(credentials, context);
    	}
    	//logger.log("query:"  + req.getQuery("param1"));
    	//logger.log("head:"  + req.getHeader("Accept"));
    	//logger.log("context:"  + gson.toJson(context));
    	//logger.log("event:"  + gson.toJson(input));
    	
    	//Response res = new Response();
    	//return res.statusCode("200")
    	//		.head("Content-Type", "*/*")
    	//		.build(logger);
    }
 
    public AWSCredentials getCredentials() {
      AWSCredentials credentials = null;
      try {
        credentials = new DefaultAWSCredentialsProviderChain().getCredentials();
      } catch (Exception e) {
        throw new AmazonClientException("Cannot load credentials " + e);
      }
    	return credentials;
    }
    
    public String listEMR(AWSCredentials credentials, Context context) {
    	LambdaLogger logger = context.getLogger();
    	
        AmazonElasticMapReduce emr = AmazonElasticMapReduceClientBuilder.standard()
        .withCredentials(new AWSStaticCredentialsProvider(credentials))
        .withRegion(Regions.AP_NORTHEAST_1)
        .build();
        
        ListClustersRequest req = new ListClustersRequest()
        	    .withClusterStates("TERMINATED" , "TERMINATED_WITH_ERRORS");
            // .withCreatedAfter(Date.valueOf("2020-04-22"));
        
        ListClustersResult clusters= emr.listClusters(req);
        
    	List<String> clusterNames = clusters.getClusters()
                                                     .stream()
                                                     .map(cluster -> cluster.getName())
                                                     .collect(Collectors.toList());

    	Response res = new Response();
    	return res.statusCode("200")
    			   .head("content-type", "application/json")
    			   .body(clusterNames)
    			   .build(logger);
    }

    public String createEMR(AWSCredentials credentials) {
      AmazonElasticMapReduce emr = AmazonElasticMapReduceClientBuilder.standard()
      .withCredentials(new AWSStaticCredentialsProvider(credentials))
      .withRegion(Regions.AP_NORTHEAST_1)
      .build();
      
      // create a step to enable debugging in the AWS Management Console
      //StepFactory stepFactory = new StepFactory();
      //StepConfig enabledebugging = new StepConfig()
      //.withName("Enable debugging")
      //.withActionOnFailure("TERMINATE_JOB_FLOW") //Valid Values:TERMINATE_JOB_FLOW | TERMINATE_CLUSTER | CANCEL_AND_WAIT | CONTINUE
      //.withHadoopJarStep(stepFactory.newEnableDebuggingStep());

      // Run a bash script using a predefined step in the StepFactory helper class
      //StepConfig runBashScript = new StepConfig()
      //.withName("Run a bash script")
      //.withHadoopJarStep(stepFactory.newScriptRunnerStep("s3://jeffgoll/emr-scripts/create_users.sh"))
      //.withActionOnFailure("CONTINUE");
      
      // Run a custom jar file as a step
      HadoopJarStepConfig hadoopConfig1 = new HadoopJarStepConfig()
      .withJar("s3://path/to/my/jarfolder") // replace with the location of the jar to run as a step
      .withMainClass("com.my.Main1") // optional main class, this can be omitted if jar above has a manifest
      .withArgs("--verbose"); // optional list of arguments to pass to the jar
      StepConfig customJarStep = new StepConfig("RunHadoopJar", hadoopConfig1);
      
      // specify applications to be installed and configured when EMR creates the cluster
      //Application hive = new Application().withName("Hive");
      Application spark = new Application().withName("Spark").withVersion("2.4.0");
      //Application ganglia = new Application().withName("Ganglia");
      //Application zeppelin = new Application().withName("Zeppelin");
      
      // create the cluster
      RunJobFlowRequest request = new RunJobFlowRequest()
      .withName("MyClusterCreatedFromJava")
      .withReleaseLabel("emr-5.20.0") // specifies the EMR release version label, we recommend the latest release
      .withSteps(customJarStep)//(enabledebugging, runBashScript, customJarStep)
      .withApplications(spark)//(hive,spark,ganglia,zeppelin)
      .withLogUri("s3://path/to/my/emr/logs") // a URI in S3 for log files is required when debugging is enabled
      .withServiceRole("EMR_DefaultRole") // replace the default with a custom IAM service role if one is used
      .withJobFlowRole("EMR_EC2_DefaultRole") // replace the default with a custom EMR role for the EC2 instance profile if one is used
      .withInstances(new JobFlowInstancesConfig()//A description of the Amazon EC2 instance running the job flow.
      .withEc2SubnetId("subnet-12ab34c56") //To launch the job flow in Amazon Virtual Private Cloud (Amazon VPC), set this parameter to the
                                           //identifier of the Amazon VPC subnet where you want the job flow to launch. If you do not specify this
                                           //value, the job flow is launched in the normal Amazon Web Services cloud, outside of an AmazonVPC.
      .withEc2KeyName("myEc2Key") //The name of the Amazon EC2 key pair that can be used to ssh to the master node as the user called hadoop.
      .withInstanceCount(3) //The number of Amazon EC2 instances used to execute the job flow.
      .withKeepJobFlowAliveWhenNoSteps(true) //Specifies whether the job flow should terminate after completing all steps.
      .withMasterInstanceType("m4.large") //The EC2 instance type of the master node.
      .withSlaveInstanceType("m4.large")); //The EC2 instance type of the slave nodes.
     
      //AddJobFlowSteps adds new steps to a running job flow.
      // A maximum of 256 steps are allowed in each job flow.
      //AddJobFlowStepsResult result = emr.addJobFlowSteps(new AddJobFlowStepsRequest()
      //.withJobFlowId("j-xxxxxxxxxxxx") // replace with cluster id to run the steps
      //.withSteps(runBashScript,myCustomJarStep));
      //System.out.println(result.getStepIds());

      RunJobFlowResult result = emr.runJobFlow(request);
      System.out.println("The cluster ID is " + result.toString());
      
      //TerminateJobFlowsRequest stopJobFlowsRequest = new TerminateJobFlowsRequest()
      //.withJobFlowIds(result.toString());
      //emr.terminateJobFlows(stopJobFlowsRequest); //TerminateJobFlows shuts a list of job flows down.
/*
        // M Family
        InstanceTypeConfig m3xLarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("m3.xlarge")
                                                 .weightedCapacity(1)
                                                 .build();
        InstanceTypeConfig m4xLarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("m4.xlarge")
                                                 .weightedCapacity(1)
                                                 .build();
        InstanceTypeConfig m5xLarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("m5.xlarge")
                                                 .weightedCapacity(1)
                                                 .build();
        // R Family
        InstanceTypeConfig r5xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("r5.xlarge")
                                                 .weightedCapacity(2)
                                                 .build();
        InstanceTypeConfig r4xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("r4.xlarge")
                                                 .weightedCapacity(2)
                                                 .build();
        InstanceTypeConfig r3xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("r3.xlarge")
                                                 .weightedCapacity(2)
                                                 .build();
        // C Family
        InstanceTypeConfig c32xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("c3.2xlarge")
                                                 .weightedCapacity(4)
                                                 .build();
        InstanceTypeConfig c42xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("c4.2xlarge")
                                                 .weightedCapacity(4)
                                                 .build();
        InstanceTypeConfig c52xlarge =  InstanceTypeConfig.builder()
                                                 .bidPriceAsPercentageOfOnDemandPrice(100.0)
                                                 .instanceType("c5.2xlarge")
                                                 .weightedCapacity(4)
                                                 .build();

        // Master
        InstanceFleetConfig masterFleet = InstanceFleetConfig.builder()
                                                .name("master-fleet")
                                                .instanceFleetType(InstanceFleetType.MASTER)
                                                .instanceTypeConfigs(Arrays.asList(
                                                  m3xLarge,
                                                  m4xLarge,
                                                  m5xLarge
                                                ))
                                                .targetOnDemandCapacity(1)
                                                .build();
        // Core
        InstanceFleetConfig coreFleet = InstanceFleetConfig.builder()
                                                .name("core-fleet")
                                                .instanceFleetType(InstanceFleetType.CORE)
                                                .instanceTypeConfigs(Arrays.asList(
                                                  m3xLarge,
                                                  m4xLarge,
                                                  r4xlarge,
                                                  r3xlarge,
                                                  c32xlarge
                                                ))
                                                .targetOnDemandCapacity(20)
                                                .targetSpotCapacity(10)
                                                .build();
        // Task
        InstanceFleetConfig taskFleet = InstanceFleetConfig.builder()
                                                .name("task-fleet")
                                                .instanceFleetType(InstanceFleetType.TASK)
                                                .instanceTypeConfigs(Arrays.asList(
                                                  m4xLarge,
                                                  r5xlarge,
                                                  r4xlarge,
                                                  c32xlarge,
                                                  c42xlarge
                                                ))
                                                .targetOnDemandCapacity(8)
                                                .targetSpotCapacity(40)
                                                .build();

        JobFlowInstancesConfig flowInstancesConfig = JobFlowInstancesConfig.builder()
                                                      .ec2KeyName(System.getenv("EC2_KEY_NAME"))
                                                      .keepJobFlowAliveWhenNoSteps(true)
                                                      .instanceFleets(Arrays.asList(
                                                        masterFleet,
                                                        coreFleet,
                                                        taskFleet
                                                      ))
                                                      .ec2SubnetIds(
                                                        System.getenv("EC2_SUBNETS_IDs").split(",")
                                                      )
                                                      .build();


        RunJobFlowRequest flowRequest = RunJobFlowRequest.builder()
                                                    .name("emr-spot-example")
                                                    .instances(flowInstancesConfig)
                                                    .serviceRole("EMR_DefaultRole")
                                                    .jobFlowRole("EMR_EC2_DefaultRole")
                                                    .visibleToAllUsers(true)
                                                    .applications(java.util.Arrays.asList(
                                                      Application.builder().name("Spark").build()
                                                    ))
                                                    .releaseLabel("emr-5.29.0")
                                                    .build();

        EmrClient emr = EmrClient.builder().build();
        RunJobFlowResponse response = emr.runJobFlow(flowRequest);
        System.out.println(response.toString());
        */
        // TODO: implement your handler
        return "Hello from Lambda!";
	}
}
