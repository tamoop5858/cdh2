package com.amazonaws.lambda.futuredata;

import java.util.Map;

public class Request {
    private Map<String, Object> rawRequest;
    
    public Request(Map<String, Object> raw) {
    	rawRequest = raw;
    }
    
    public String getPath() {
    	return rawRequest.containsKey("path") ? rawRequest.get("path").toString() : "";
    }
    
    public String getMethod() {
    	return rawRequest.containsKey("httpMethod") ? rawRequest.get("httpMethod").toString() : "";
    }
    
    public String getQuery(String key) {
    	@SuppressWarnings("unchecked")
		Map<String, Object> params = (Map<String, Object>) rawRequest.get("queryStringParameters");
    	
    	if (params != null)
    		return params.containsKey(key) ? params.get(key).toString() : "";
    	else
    		return "";
    }
    
    public String getHeader(String key) {
    	@SuppressWarnings("unchecked")
		Map<String, Object> params = (Map<String, Object>) rawRequest.get("headers");
    	
    	if (params != null)
    		return params.containsKey(key) ? params.get(key).toString() : "";
    	else
    		return "";
    }
    
}
