package com.amazonaws.lambda.futuredata;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class Response {
    Map<String, Object> res = new HashMap<String, Object>();
    
    public Response() {
    }
    
    public Response statusCode(String sc) {
    	res.put("statusCode", sc);
    	return this;
    }
 
    public Response body(Object bd) {
    	res.put("body", bd);
    	return this;
    }
 
    public Response head(String key, String v) {
    	@SuppressWarnings("unchecked")
		Map<String, Object> headers = (Map<String, Object>) res.get("headers");
    	
    	if(headers == null) {
    		headers = new HashMap<String, Object>();
    		res.put("headers",  headers);
    		headers.put(key, v);
    	} else {
    		headers.put(key,  v);
    	}
    	return this;
    }
    
    public String build(LambdaLogger logger) {
    	final ObjectMapper mapper = new ObjectMapper();
    	final ObjectWriter writer = mapper.writer();

			String rv = "";
			try {
				rv = writer.writeValueAsString(res);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        logger.log(rv);
    	return rv;
    }
}